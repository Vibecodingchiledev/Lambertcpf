import { useScrollAnimation } from "@/hooks/useScrollAnimation"
import { MapPin, Clock, Star } from "lucide-react"

const locations = [
  {
    name: "Santiago Centro",
    address: "Av. Libertador Bernardo O'Higgins 1234",
    hours: "Lun - Vie: 08:00 - 20:00",
    badge: "Flagship",
    image: "/location-santiago.jpg",
  },
  {
    name: "Coquimbo",
    address: "Costanera Coquimbo, Local 45",
    hours: "Lun - Dom: 09:00 - 22:00",
    badge: "Origen",
    image: "/location-coquimbo.jpg",
  },
  {
    name: "Bahia Inglesa",
    address: "Calle Principal 89, Playa Grande",
    hours: "Mar - Dom: 10:00 - 21:00",
    badge: "Vista al Mar",
    image: "/location-bahia.jpg",
  },
]

export default function Locations() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation(0.2)
  const { ref: gridRef, isVisible: gridVisible } = useScrollAnimation(0.1)

  return (
    <section id="locations" className="py-24 md:py-32 bg-[#2C1810]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        {/* Header */}
        <div
          ref={headerRef}
          className={`text-center mb-16 transition-all duration-700 ${
            headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <span className="inline-block text-xs font-semibold uppercase tracking-[0.1em] text-[#D84315] mb-4">
            Encuentranos
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-semibold text-[#FFF8E1]">
            Nuestras Ubicaciones
          </h2>
        </div>

        {/* Cards */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16"
        >
          {locations.map((loc, index) => (
            <div
              key={loc.name}
              className={`group bg-[#1A120B] rounded-2xl overflow-hidden border border-[#3E2723] transition-all duration-[400ms] hover:border-[#D84315] hover:shadow-[0_8px_32px_rgba(216,67,21,0.25)] hover:-translate-y-1 ${
                gridVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: gridVisible ? `${index * 100}ms` : "0ms" }}
            >
              {/* Image */}
              <div className="aspect-[16/9] overflow-hidden relative">
                <img
                  src={loc.image}
                  alt={loc.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute top-4 left-4">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#D84315] text-[#FFF8E1] text-xs font-semibold">
                    <Star className="w-3 h-3" />
                    {loc.badge}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="font-['Playfair_Display'] text-xl font-semibold text-[#FFF8E1] mb-3">
                  {loc.name}
                </h3>
                <div className="space-y-2">
                  <div className="flex items-start gap-2 text-sm text-[#BCAAA4]">
                    <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-[#D84315]" />
                    <span>{loc.address}</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm text-[#BCAAA4]">
                    <Clock className="w-4 h-4 mt-0.5 shrink-0 text-[#D84315]" />
                    <span>{loc.hours}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Map Conceptual */}
        <div className="flex justify-center">
          <div className="relative w-full max-w-[600px]">
            <svg viewBox="0 0 400 600" className="w-full h-auto opacity-40">
              {/* Simplified Chile shape */}
              <path
                d="M180,20 C220,30 240,50 230,80 C220,110 210,140 215,170 C220,200 235,230 240,260 C245,290 235,320 230,350 C225,380 235,410 240,440 C245,470 235,500 230,530 C225,560 210,580 190,590 C170,580 160,560 155,530 C150,500 160,470 165,440 C170,410 160,380 155,350 C150,320 160,290 165,260 C170,230 155,200 150,170 C145,140 155,110 160,80 C165,50 160,30 180,20 Z"
                fill="#3E2723"
                stroke="#D84315"
                strokeWidth="1"
              />
            </svg>
            {/* Location dots */}
            <div className="absolute top-[12%] left-[55%] group">
              <div className="w-4 h-4 rounded-full bg-[#D84315] animate-pulse" />
              <div className="absolute left-6 top-0 text-xs text-[#FFF8E1] font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Santiago
              </div>
            </div>
            <div className="absolute top-[22%] left-[58%] group">
              <div className="w-3 h-3 rounded-full bg-[#D84315]" />
              <div className="absolute left-5 top-0 text-xs text-[#FFF8E1] font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                San Miguel
              </div>
            </div>
            <div className="absolute top-[38%] left-[48%] group">
              <div className="w-4 h-4 rounded-full bg-[#01579B] animate-pulse" />
              <div className="absolute left-6 top-0 text-xs text-[#FFF8E1] font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Coquimbo
              </div>
            </div>
            <div className="absolute top-[44%] left-[50%] group">
              <div className="w-3 h-3 rounded-full bg-[#01579B]" />
              <div className="absolute left-5 top-0 text-xs text-[#FFF8E1] font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Bahia Inglesa
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
