import { useScrollAnimation } from "@/hooks/useScrollAnimation"

export default function About() {
  const { ref: leftRef, isVisible: leftVisible } = useScrollAnimation(0.2)
  const { ref: rightRef, isVisible: rightVisible } = useScrollAnimation(0.2)

  return (
    <section id="about" className="py-24 md:py-32 bg-[#1A120B]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left - Image */}
          <div
            ref={leftRef}
            className={`transition-all duration-[800ms] ease-out ${
              leftVisible
                ? "opacity-100 translate-x-0"
                : "opacity-0 -translate-x-10"
            }`}
          >
            <div className="relative rounded-3xl overflow-hidden aspect-[4/5]">
              <img
                src="/about-roast.jpg"
                alt="Tostado artesanal de cafe"
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[rgba(26,18,11,0.5)] to-transparent" />
            </div>
          </div>

          {/* Right - Content */}
          <div
            ref={rightRef}
            className={`transition-all duration-[800ms] ease-out delay-200 ${
              rightVisible
                ? "opacity-100 translate-x-0"
                : "opacity-0 translate-x-10"
            }`}
          >
            <span className="inline-block text-xs font-semibold uppercase tracking-[0.1em] text-[#D84315] mb-4">
              Nuestra Historia
            </span>
            <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-semibold text-[#FFF8E1] mb-6 leading-tight">
              De la Costa a tu Taza
            </h2>
            <div className="space-y-4 text-[#BCAAA4] leading-relaxed mb-10">
              <p>
                Lambert Coffee nacio en Coquimbo, inspirados por el espiritu indomito del Fuerte Lambert y la serenidad de Bahia Inglesa. Cada grano que tostamos lleva la esencia del Pacifico chileno: intensidad, calidez y un toque de sal marina.
              </p>
              <p>
                Hoy operamos en Santiago, San Miguel, Coquimbo y Bahia Inglesa, llevando cafe de especialidad a cada rincón donde la comunidad busca calidad y autenticidad.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center lg:text-left">
                <div className="font-['Playfair_Display'] text-3xl md:text-4xl text-[#D84315] font-bold">
                  4
                </div>
                <div className="text-sm text-[#BCAAA4] mt-1">Ubicaciones</div>
              </div>
              <div className="text-center lg:text-left border-l border-r border-[#3E2723]">
                <div className="font-['Playfair_Display'] text-3xl md:text-4xl text-[#D84315] font-bold px-4">
                  12
                </div>
                <div className="text-sm text-[#BCAAA4] mt-1">Años</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="font-['Playfair_Display'] text-3xl md:text-4xl text-[#D84315] font-bold">
                  50K+
                </div>
                <div className="text-sm text-[#BCAAA4] mt-1">Clientes</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
