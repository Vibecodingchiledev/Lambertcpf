import { useState, useEffect, useCallback } from "react"
import { useScrollAnimation } from "@/hooks/useScrollAnimation"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

const testimonials = [
  {
    text: "El mejor cappuccino de Santiago. Se nota que el tostado es artesanal y que les importa cada detalle.",
    author: "Camila R.",
    location: "Santiago",
  },
  {
    text: "Vengo a la ubicacion de Coquimbo cada fin de semana. La vista al mar con un espresso Lambert no tiene precio.",
    author: "Diego M.",
    location: "Coquimbo",
  },
  {
    text: "El cold brew de verano es mi adiccion. Refrescante, intenso y con ese toque citrico unico.",
    author: "Valentina S.",
    location: "Bahia Inglesa",
  },
  {
    text: "Atencion impecable, ambiente acogedor y el tiramisu... simplemente divino. Mi lugar favorito en San Miguel.",
    author: "Andres L.",
    location: "San Miguel",
  },
]

export default function Testimonials() {
  const [current, setCurrent] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const { ref, isVisible } = useScrollAnimation(0.2)

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % testimonials.length)
  }, [])

  const prev = useCallback(() => {
    setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }, [])

  useEffect(() => {
    if (isPaused) return
    const interval = setInterval(next, 5000)
    return () => clearInterval(interval)
  }, [isPaused, next])

  return (
    <section
      id="testimonials"
      className="py-24 md:py-32 bg-[#2C1810]"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        {/* Header */}
        <div
          ref={ref}
          className={`text-center mb-16 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <span className="inline-block text-xs font-semibold uppercase tracking-[0.1em] text-[#D84315] mb-4">
            Testimonios
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-semibold text-[#FFF8E1]">
            Lo que Dicen Nuestros Clientes
          </h2>
        </div>

        {/* Carousel */}
        <div className="relative max-w-[800px] mx-auto">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {testimonials.map((t, i) => (
                <div key={i} className="w-full shrink-0 px-4">
                  <div className="bg-[#1A120B] rounded-2xl p-8 md:p-12 relative border-t-[3px] border-[#D84315]">
                    {/* Quote icon */}
                    <Quote className="absolute top-6 left-6 w-12 h-12 text-[#D84315] opacity-30" />

                    <p className="text-lg md:text-xl text-[#FFF8E1] leading-relaxed mb-8 relative z-10 italic">
                      "{t.text}"
                    </p>

                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#D84315] flex items-center justify-center text-[#FFF8E1] font-semibold text-sm">
                        {t.author.charAt(0)}
                      </div>
                      <div>
                        <div className="text-[#FFF8E1] font-medium">{t.author}</div>
                        <div className="text-sm text-[#BCAAA4]">{t.location}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-10 h-10 rounded-full bg-[#2C1810] border border-[#3E2723] flex items-center justify-center text-[#BCAAA4] hover:text-[#FFF8E1] hover:border-[#D84315] transition-colors z-10"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-10 h-10 rounded-full bg-[#2C1810] border border-[#3E2723] flex items-center justify-center text-[#BCAAA4] hover:text-[#FFF8E1] hover:border-[#D84315] transition-colors z-10"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  i === current
                    ? "bg-[#D84315] w-6"
                    : "bg-[#3E2723] hover:bg-[#BCAAA4]"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
