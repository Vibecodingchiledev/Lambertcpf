import { useScrollAnimation } from "@/hooks/useScrollAnimation"

const specialties = [
  {
    name: "Espresso Lambert",
    description: "Doble shot intenso con notas de chocolate amargo y caramelo.",
    price: "$2.900",
    image: "/specialty-1.jpg",
  },
  {
    name: "Cappuccino Bahia",
    description: "Espresso con leche texturizada, inspirado en las olas de Bahia Inglesa.",
    price: "$3.900",
    image: "/specialty-2.jpg",
  },
  {
    name: "Cold Brew Pacifico",
    description: "Extraccion en frio por 18 horas, cuerpo suave y notas citricas.",
    price: "$4.500",
    image: "/specialty-3.jpg",
  },
  {
    name: "Tiramisu Artesanal",
    description: "Postre italiano con cafe Lambert, mascarpone casero y cacao.",
    price: "$5.500",
    image: "/specialty-4.jpg",
  },
]

export default function Specialties() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation(0.2)
  const { ref: gridRef, isVisible: gridVisible } = useScrollAnimation(0.1)

  return (
    <section id="specialties" className="py-24 md:py-32 bg-[#1A120B]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        {/* Header */}
        <div
          ref={headerRef}
          className={`text-center mb-16 transition-all duration-700 ${
            headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <span className="inline-block text-xs font-semibold uppercase tracking-[0.1em] text-[#D84315] mb-4">
            Nuestro Menu
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-semibold text-[#FFF8E1] mb-4">
            Especialidades que Enamoran
          </h2>
          <p className="text-[#BCAAA4] max-w-[600px] mx-auto leading-relaxed">
            Cada bebida es una obra de arte, preparada con granos seleccionados y tecnicas de extraccion precisas.
          </p>
        </div>

        {/* Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {specialties.map((item, index) => (
            <div
              key={item.name}
              className={`group bg-[#2C1810] border border-[rgba(62,39,35,0.5)] rounded-2xl overflow-hidden transition-all duration-[400ms] hover:border-[#D84315] hover:shadow-[0_8px_32px_rgba(216,67,21,0.25)] hover:-translate-y-1 ${
                gridVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-10"
              }`}
              style={{ transitionDelay: gridVisible ? `${index * 100}ms` : "0ms" }}
            >
              {/* Image */}
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="font-semibold text-lg text-[#FFF8E1] mb-2">
                  {item.name}
                </h3>
                <p className="text-sm text-[#BCAAA4] leading-relaxed mb-4">
                  {item.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="font-['Playfair_Display'] text-2xl text-[#D84315] font-bold">
                    {item.price}
                  </span>
                  <span className="text-xs text-[#BCAAA4]">CLP</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
