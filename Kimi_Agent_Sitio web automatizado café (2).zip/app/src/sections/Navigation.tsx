import { useState, useEffect } from "react"
import { Link } from "react-router"
import { Menu, X, Coffee, User, LogOut, LayoutDashboard } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/hooks/useAuth"

const navLinks = [
  { label: "Inicio", href: "#hero" },
  { label: "Nosotros", href: "#about" },
  { label: "Especialidades", href: "#specialties" },
  { label: "Ubicaciones", href: "#locations" },
  { label: "Contacto", href: "#contact" },
]

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { user, isLoading, logout } = useAuth()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80)
    }
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollTo = (href: string) => {
    setMobileOpen(false)
    const el = document.querySelector(href)
    if (el) {
      el.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[rgba(26,18,11,0.95)] backdrop-blur-xl shadow-[0_2px_20px_rgba(0,0,0,0.5)] border-b border-[rgba(255,248,225,0.1)]"
          : "bg-transparent border-b border-[rgba(255,248,225,0.05)]"
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8 h-[72px] flex items-center justify-between">
        {/* Logo */}
        <button onClick={() => scrollTo("#hero")} className="flex items-center gap-2 group">
          <Coffee className="w-7 h-7 text-[#D84315] transition-transform group-hover:rotate-12" />
          <span className="font-['Playfair_Display'] text-xl font-bold text-[#FFF8E1]">
            Lambert
          </span>
          <span className="text-sm font-medium text-[#BCAAA4] mt-1">Coffee</span>
        </button>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => scrollTo(link.href)}
              className="text-sm font-medium uppercase tracking-[0.05em] text-[#BCAAA4] hover:text-[#FFF8E1] transition-colors duration-300"
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Right Actions */}
        <div className="hidden lg:flex items-center gap-4">
          <button
            onClick={() => scrollTo("#locations")}
            className="px-6 py-2.5 rounded-full bg-[#D84315] text-[#FFF8E1] text-sm font-semibold uppercase tracking-[0.05em] hover:bg-[#BF360C] hover:-translate-y-0.5 hover:shadow-[0_4px_16px_rgba(216,67,21,0.4)] transition-all duration-300"
          >
            Reservar
          </button>

          {!isLoading && user ? (
            <div className="relative group">
              <button className="flex items-center gap-2 text-[#BCAAA4] hover:text-[#FFF8E1] transition-colors">
                {user.avatar ? (
                  <img src={user.avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
                ) : (
                  <User className="w-5 h-5" />
                )}
                <span className="text-sm">{user.name || "Usuario"}</span>
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 bg-[#2C1810] border border-[#3E2723] rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <div className="py-2">
                  {user.role === "admin" && (
                    <Link
                      to="/dashboard"
                      className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#BCAAA4] hover:text-[#FFF8E1] hover:bg-[#3E2723] transition-colors"
                    >
                      <LayoutDashboard className="w-4 h-4" />
                      Dashboard
                    </Link>
                  )}
                  <button
                    onClick={() => logout()}
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#BCAAA4] hover:text-[#FFF8E1] hover:bg-[#3E2723] transition-colors w-full text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    Cerrar Sesión
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <Link
              to="/login"
              className="text-sm font-medium text-[#BCAAA4] hover:text-[#FFF8E1] transition-colors"
            >
              Iniciar Sesión
            </Link>
          )}
        </div>

        {/* Mobile Menu */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild className="lg:hidden">
            <button className="text-[#FFF8E1] p-2">
              <Menu className="w-6 h-6" />
            </button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] bg-[#1A120B] border-l border-[#3E2723] p-0">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-6 border-b border-[#3E2723]">
                <span className="font-['Playfair_Display'] text-xl font-bold text-[#FFF8E1]">
                  Lambert Coffee
                </span>
                <button onClick={() => setMobileOpen(false)} className="text-[#BCAAA4]">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 py-6">
                {navLinks.map((link) => (
                  <button
                    key={link.href}
                    onClick={() => scrollTo(link.href)}
                    className="block w-full text-left px-6 py-4 text-[#BCAAA4] hover:text-[#FFF8E1] hover:bg-[#2C1810] transition-colors border-b border-[#3E2723]"
                  >
                    {link.label}
                  </button>
                ))}
              </div>
              <div className="p-6 border-t border-[#3E2723] space-y-3">
                {!isLoading && user ? (
                  <>
                    {user.role === "admin" && (
                      <Link
                        to="/dashboard"
                        onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-2 px-4 py-3 rounded-lg bg-[#2C1810] text-[#BCAAA4] hover:text-[#FFF8E1] transition-colors"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        Dashboard
                      </Link>
                    )}
                    <button
                      onClick={() => { logout(); setMobileOpen(false); }}
                      className="flex items-center gap-2 px-4 py-3 rounded-lg bg-[#2C1810] text-[#BCAAA4] hover:text-[#FFF8E1] transition-colors w-full"
                    >
                      <LogOut className="w-4 h-4" />
                      Cerrar Sesión
                    </button>
                  </>
                ) : (
                  <Link
                    to="/login"
                    onClick={() => setMobileOpen(false)}
                    className="block w-full text-center px-4 py-3 rounded-lg bg-[#D84315] text-[#FFF8E1] font-semibold"
                  >
                    Iniciar Sesión
                  </Link>
                )}
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  )
}
