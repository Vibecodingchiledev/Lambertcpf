import { useState } from "react"
import { useScrollAnimation } from "@/hooks/useScrollAnimation"
import { trpc } from "@/providers/trpc"
import { Mail, Check, Loader2 } from "lucide-react"
import { toast } from "sonner"

export default function Newsletter() {
  const [email, setEmail] = useState("")
  const [submitted, setSubmitted] = useState(false)
  const { ref, isVisible } = useScrollAnimation(0.2)

  const subscribe = trpc.newsletter.subscribe.useMutation({
    onSuccess: () => {
      setSubmitted(true)
      setEmail("")
      toast.success("Suscripcion exitosa", {
        description: "Bienvenido a Lambert Coffee",
      })
    },
    onError: () => {
      toast.error("Error al suscribirse", {
        description: "Por favor intenta de nuevo",
      })
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !email.includes("@")) {
      toast.error("Email invalido")
      return
    }
    subscribe.mutate({ email })
  }

  return (
    <section className="py-20 md:py-24 bg-gradient-to-br from-[#D84315] to-[#01579B]">
      <div className="max-w-[800px] mx-auto px-4 sm:px-8 text-center">
        <div
          ref={ref}
          className={`transition-all duration-700 ${
            isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
        >
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-semibold text-[#FFF8E1] mb-4">
            Unete a la Familia Lambert
          </h2>
          <p className="text-[rgba(255,248,225,0.8)] mb-8 max-w-[500px] mx-auto">
            Suscribete para recibir ofertas exclusivas, lanzamientos de temporada e invitaciones a eventos de cata.
          </p>

          {submitted ? (
            <div className="flex items-center justify-center gap-2 text-[#FFF8E1]">
              <Check className="w-5 h-5" />
              <span className="font-medium">
                Bienvenido a Lambert Coffee! Revisa tu correo.
              </span>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-[500px] mx-auto"
            >
              <div className="relative flex-1">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#BCAAA4]" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu@email.com"
                  className="w-full pl-12 pr-4 py-3.5 rounded-xl bg-[#1A120B] border border-[#3E2723] text-[#FFF8E1] placeholder-[#BCAAA4] focus:outline-none focus:border-[#D84315] focus:ring-2 focus:ring-[rgba(216,67,21,0.2)] transition-all"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={subscribe.isPending}
                className="px-8 py-3.5 rounded-xl bg-[#1A120B] text-[#FFF8E1] font-semibold hover:bg-[#2C1810] transition-colors disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {subscribe.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  "Suscribirse"
                )}
              </button>
            </form>
          )}

          <p className="text-xs text-[rgba(255,248,225,0.6)] mt-4">
            Respetamos tu privacidad. Sin spam, solo cafe de calidad.
          </p>
        </div>
      </div>
    </section>
  )
}
