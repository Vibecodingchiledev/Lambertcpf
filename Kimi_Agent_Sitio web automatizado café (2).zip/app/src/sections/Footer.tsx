import { Coffee, Instagram, MessageCircle, Phone, Facebook } from "lucide-react"

export default function Footer() {
  const scrollTo = (href: string) => {
    const el = document.querySelector(href)
    if (el) {
      el.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <footer className="bg-[#0D0906] pt-16 pb-8">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <Coffee className="w-6 h-6 text-[#D84315]" />
              <span className="font-['Playfair_Display'] text-xl font-bold text-[#FFF8E1]">
                Lambert
              </span>
              <span className="text-sm text-[#BCAAA4]">Coffee</span>
            </div>
            <p className="text-sm text-[#BCAAA4] leading-relaxed mb-4">
              Cafe de especialidad con alma chilena. Tostado artesanalmente en la costa del Pacifico.
            </p>
            <p className="text-xs text-[#BCAAA4]">
              &copy; 2025 Lambert Coffee. Todos los derechos reservados.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-[#FFF8E1] mb-4">Enlaces</h4>
            <ul className="space-y-2">
              {[
                { label: "Inicio", href: "#hero" },
                { label: "Nosotros", href: "#about" },
                { label: "Especialidades", href: "#specialties" },
                { label: "Ubicaciones", href: "#locations" },
                { label: "Contacto", href: "#contact" },
              ].map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="text-sm text-[#BCAAA4] hover:text-[#D84315] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Locations */}
          <div>
            <h4 className="font-semibold text-[#FFF8E1] mb-4">Ubicaciones</h4>
            <ul className="space-y-2">
              {["Santiago Centro", "San Miguel", "Coquimbo", "Bahia Inglesa"].map(
                (loc) => (
                  <li key={loc} className="text-sm text-[#BCAAA4]">
                    {loc}
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-semibold text-[#FFF8E1] mb-4">Redes Sociales</h4>
            <div className="space-y-3">
              <a
                href="https://instagram.com/lambert.coffee"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#BCAAA4] hover:text-[#D84315] transition-colors"
              >
                <Instagram className="w-4 h-4" />
                @lambert.coffee
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#BCAAA4] hover:text-[#D84315] transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                TikTok
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#BCAAA4] hover:text-[#D84315] transition-colors"
              >
                <Facebook className="w-4 h-4" />
                Facebook
              </a>
              <a
                href="https://wa.me/56963153117"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#BCAAA4] hover:text-[#D84315] transition-colors"
              >
                <Phone className="w-4 h-4" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[#3E2723] pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-[#BCAAA4]">
            Hecho con cafe en Chile
          </p>
          <div className="flex gap-4 text-xs text-[#BCAAA4]">
            <button className="hover:text-[#FFF8E1] transition-colors">
              Politica de Privacidad
            </button>
            <span>|</span>
            <button className="hover:text-[#FFF8E1] transition-colors">
              Terminos de Servicio
            </button>
          </div>
        </div>
      </div>
    </footer>
  )
}
