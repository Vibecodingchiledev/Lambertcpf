import { useScrollAnimation } from "@/hooks/useScrollAnimation"
import { Coffee, Flame, Timer, Droplets } from "lucide-react"

const steps = [
  {
    icon: Coffee,
    title: "Seleccion",
    description: "Elegimos los mejores granos arabica de pequeños productores chilenos.",
    image: "/process-1.jpg",
  },
  {
    icon: Flame,
    title: "Tostado",
    description: "Tostamos en pequenos lotes para controlar el perfil de sabor al detalle.",
    image: "/process-2.jpg",
  },
  {
    icon: Timer,
    title: "Molienda",
    description: "Molienda a demanda para preservar los aromas y aceites esenciales.",
    image: "/process-3.jpg",
  },
  {
    icon: Droplets,
    title: "Extraccion",
    description: "Preparacion precisa con metodos pour-over, espresso y cold brew.",
    image: "/hero-bg.jpg",
  },
]

export default function Process() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation(0.2)
  const { ref: stepsRef, isVisible: stepsVisible } = useScrollAnimation(0.1)

  return (
    <section id="process" className="py-24 md:py-32 bg-[#1A120B]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        {/* Header */}
        <div
          ref={headerRef}
          className={`text-center mb-16 transition-all duration-700 ${
            headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <span className="inline-block text-xs font-semibold uppercase tracking-[0.1em] text-[#D84315] mb-4">
            Proceso
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-semibold text-[#FFF8E1]">
            Del Grano a tu Taza
          </h2>
        </div>

        {/* Steps - Desktop horizontal, Mobile vertical */}
        <div ref={stepsRef} className="relative">
          {/* Progress line - desktop */}
          <div className="hidden lg:block absolute top-[60px] left-[12.5%] right-[12.5%] h-0.5 bg-[#3E2723]">
            <div
              className={`h-full bg-gradient-to-r from-[#3E2723] to-[#D84315] transition-all duration-1000 ${
                stepsVisible ? "w-full" : "w-0"
              }`}
            />
          </div>

          {/* Progress line - mobile */}
          <div className="lg:hidden absolute top-0 bottom-0 left-[28px] w-0.5 bg-[#3E2723]">
            <div
              className={`w-full bg-gradient-to-b from-[#3E2723] to-[#D84315] transition-all duration-1000 ${
                stepsVisible ? "h-full" : "h-0"
              }`}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 lg:gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon
              return (
                <div
                  key={step.title}
                  className={`relative flex lg:flex-col items-start lg:items-center gap-6 lg:gap-0 transition-all duration-700 ${
                    stepsVisible
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 translate-y-10"
                  }`}
                  style={{ transitionDelay: stepsVisible ? `${index * 150}ms` : "0ms" }}
                >
                  {/* Icon + Image circle */}
                  <div className="relative shrink-0 z-10">
                    <div className="w-14 h-14 lg:w-[120px] lg:h-[120px] rounded-full bg-[#2C1810] border-2 border-[#D84315] flex items-center justify-center overflow-hidden lg:mb-6">
                      <img
                        src={step.image}
                        alt={step.title}
                        className="w-full h-full object-cover opacity-60"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Icon className="w-6 h-6 lg:w-8 lg:h-8 text-[#D84315]" />
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="lg:text-center pt-2 lg:pt-0">
                    <h3 className="font-['Playfair_Display'] text-lg font-semibold text-[#FFF8E1] mb-2">
                      {step.title}
                    </h3>
                    <p className="text-sm text-[#BCAAA4] leading-relaxed max-w-[240px]">
                      {step.description}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
