import { useState } from "react"
import { useScrollAnimation } from "@/hooks/useScrollAnimation"
import { trpc } from "@/providers/trpc"
import { Phone, Mail, Instagram, MessageCircle, MapPin, Send, Loader2 } from "lucide-react"
import { toast } from "sonner"

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    location: "general",
    message: "",
  })
  const { ref: leftRef, isVisible: leftVisible } = useScrollAnimation(0.2)
  const { ref: rightRef, isVisible: rightVisible } = useScrollAnimation(0.2)

  const contact = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setForm({ name: "", email: "", location: "general", message: "" })
      toast.success("Mensaje enviado", {
        description: "Te responderemos en menos de 24 horas",
      })
    },
    onError: () => {
      toast.error("Error al enviar", {
        description: "Por favor intenta de nuevo",
      })
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || form.name.length < 2) {
      toast.error("Nombre muy corto")
      return
    }
    if (!form.email.includes("@")) {
      toast.error("Email invalido")
      return
    }
    if (!form.message || form.message.length < 10) {
      toast.error("Mensaje muy corto (min 10 caracteres)")
      return
    }
    contact.mutate(form as {
      name: string
      email: string
      location: "santiago" | "san_miguel" | "coquimbo" | "bahia_inglesa" | "general"
      message: string
    })
  }

  return (
    <section id="contact" className="py-24 md:py-32 bg-[#1A120B]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Left - Info */}
          <div
            ref={leftRef}
            className={`lg:col-span-2 transition-all duration-[800ms] ${
              leftVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
          >
            <span className="inline-block text-xs font-semibold uppercase tracking-[0.1em] text-[#D84315] mb-4">
              Contacto
            </span>
            <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl font-semibold text-[#FFF8E1] mb-6">
              Hablemos de Cafe
            </h2>
            <p className="text-[#BCAAA4] leading-relaxed mb-8">
              Tienes preguntas sobre nuestras ubicaciones, productos o servicios para eventos? Escribenos y te responderemos en menos de 24 horas.
            </p>

            <div className="space-y-5 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#2C1810] flex items-center justify-center">
                  <Phone className="w-5 h-5 text-[#D84315]" />
                </div>
                <div>
                  <div className="text-sm text-[#BCAAA4]">Telefono</div>
                  <div className="text-[#FFF8E1]">+56 9 6315 3117</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#2C1810] flex items-center justify-center">
                  <Mail className="w-5 h-5 text-[#D84315]" />
                </div>
                <div>
                  <div className="text-sm text-[#BCAAA4]">Email</div>
                  <div className="text-[#FFF8E1]">hola@lambertcoffee.cl</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#2C1810] flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-[#D84315]" />
                </div>
                <div>
                  <div className="text-sm text-[#BCAAA4]">Instagram</div>
                  <div className="text-[#FFF8E1]">@lambert.coffee</div>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-3">
              <a
                href="https://instagram.com/lambert.coffee"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-[#2C1810] flex items-center justify-center text-[#BCAAA4] hover:text-[#D84315] hover:bg-[#3E2723] transition-all"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-[#2C1810] flex items-center justify-center text-[#BCAAA4] hover:text-[#D84315] hover:bg-[#3E2723] transition-all"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
              <a
                href="https://wa.me/56963153117"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-[#2C1810] flex items-center justify-center text-[#BCAAA4] hover:text-[#D84315] hover:bg-[#3E2723] transition-all"
              >
                <Phone className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Right - Form */}
          <div
            ref={rightRef}
            className={`lg:col-span-3 transition-all duration-[800ms] delay-200 ${
              rightVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
          >
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-[#BCAAA4] mb-2">
                    Nombre
                  </label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Tu nombre"
                    className="w-full px-4 py-3 rounded-lg bg-[#2C1810] border border-[#3E2723] text-[#FFF8E1] placeholder-[#BCAAA4] focus:outline-none focus:border-[#D84315] focus:ring-2 focus:ring-[rgba(216,67,21,0.2)] transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#BCAAA4] mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="tu@email.com"
                    className="w-full px-4 py-3 rounded-lg bg-[#2C1810] border border-[#3E2723] text-[#FFF8E1] placeholder-[#BCAAA4] focus:outline-none focus:border-[#D84315] focus:ring-2 focus:ring-[rgba(216,67,21,0.2)] transition-all"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#BCAAA4] mb-2">
                  Ubicacion de interes
                </label>
                <select
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-[#2C1810] border border-[#3E2723] text-[#FFF8E1] focus:outline-none focus:border-[#D84315] focus:ring-2 focus:ring-[rgba(216,67,21,0.2)] transition-all appearance-none"
                >
                  <option value="general">General</option>
                  <option value="santiago">Santiago</option>
                  <option value="san_miguel">San Miguel</option>
                  <option value="coquimbo">Coquimbo</option>
                  <option value="bahia_inglesa">Bahia Inglesa</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#BCAAA4] mb-2">
                  Mensaje
                </label>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Cuentanos como podemos ayudarte..."
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg bg-[#2C1810] border border-[#3E2723] text-[#FFF8E1] placeholder-[#BCAAA4] focus:outline-none focus:border-[#D84315] focus:ring-2 focus:ring-[rgba(216,67,21,0.2)] transition-all resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={contact.isPending}
                className="w-full py-3.5 rounded-xl bg-[#D84315] text-[#FFF8E1] font-semibold uppercase tracking-[0.05em] hover:bg-[#BF360C] transition-all disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {contact.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Enviar Mensaje
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
