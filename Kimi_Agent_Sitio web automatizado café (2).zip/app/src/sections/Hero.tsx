import { MapPin, ChevronDown } from "lucide-react"

export default function Hero() {
  const scrollTo = (href: string) => {
    const el = document.querySelector(href)
    if (el) {
      el.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/hero-bg.jpg"
          alt="Lambert Coffee interior"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[rgba(26,18,11,0.3)] to-[rgba(26,18,11,0.85)]" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-[800px] mx-auto px-4 text-center">
        {/* Badge */}
        <div
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[rgba(216,67,21,0.2)] border border-[rgba(216,67,21,0.3)] mb-8 animate-[fadeInUp_0.6s_ease-out_both]"
        >
          <MapPin className="w-4 h-4 text-[#D84315]" />
          <span className="text-sm font-medium text-[#FFF8E1]">
            Desde Coquimbo para Chile
          </span>
        </div>

        {/* Headline */}
        <h1
          className="font-['Playfair_Display'] text-4xl sm:text-5xl md:text-7xl font-bold text-[#FFF8E1] leading-tight mb-6 animate-[fadeInUp_0.7s_ease-out_0.2s_both]"
        >
          El Autentico Sabor del Pacifico
        </h1>

        {/* Subtitle */}
        <p
          className="text-base sm:text-lg text-[#BCAAA4] max-w-[560px] mx-auto mb-10 leading-relaxed animate-[fadeInUp_0.6s_ease-out_0.4s_both]"
        >
          Cafe de especialidad tostado artesanalmente en la costa chilena. Vivimos el cafe con la pasion de Bahia Inglesa.
        </p>

        {/* CTAs */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-[fadeInUp_0.6s_ease-out_0.6s_both]"
        >
          <button
            onClick={() => scrollTo("#about")}
            className="px-8 py-3.5 rounded-full bg-[#D84315] text-[#FFF8E1] text-sm font-semibold uppercase tracking-[0.05em] hover:bg-[#BF360C] hover:-translate-y-0.5 hover:shadow-[0_4px_16px_rgba(216,67,21,0.4)] active:translate-y-0 transition-all duration-300"
          >
            Conoce Nuestra Historia
          </button>
          <button
            onClick={() => scrollTo("#locations")}
            className="px-8 py-3.5 rounded-full border border-[#FFF8E1] text-[#FFF8E1] text-sm font-semibold uppercase tracking-[0.05em] hover:bg-[rgba(255,248,225,0.1)] transition-all duration-300"
          >
            Ver Ubicaciones
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={() => scrollTo("#about")}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[#FFF8E1] opacity-60 animate-bounce"
      >
        <ChevronDown className="w-6 h-6" />
      </button>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  )
}
