import Navigation from "@/sections/Navigation"
import Hero from "@/sections/Hero"
import About from "@/sections/About"
import Specialties from "@/sections/Specialties"
import Locations from "@/sections/Locations"
import Process from "@/sections/Process"
import Testimonials from "@/sections/Testimonials"
import Newsletter from "@/sections/Newsletter"
import Contact from "@/sections/Contact"
import Footer from "@/sections/Footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#1A120B]">
      <Navigation />
      <Hero />
      <About />
      <Specialties />
      <Locations />
      <Process />
      <Testimonials />
      <Newsletter />
      <Contact />
      <Footer />
    </main>
  )
}
