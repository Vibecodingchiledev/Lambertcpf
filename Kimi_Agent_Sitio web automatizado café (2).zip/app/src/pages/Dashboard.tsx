import { useState, useEffect } from "react"
import { useNavigate, Link } from "react-router"
import { useAuth } from "@/hooks/useAuth"
import { trpc } from "@/providers/trpc"
import {
  LayoutDashboard,
  MessageSquare,
  Users,
  Settings,
  LogOut,
  Mail,
  Eye,
  Trash2,
  Inbox,
  UserCheck,
  TrendingUp,
  ArrowLeft,
  Loader2,
} from "lucide-react"
import { toast } from "sonner"

type Tab = "overview" | "messages" | "subscribers"

export default function Dashboard() {
  const { user, isLoading: authLoading, isAuthenticated, logout } = useAuth({
    redirectOnUnauthenticated: true,
  })
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<Tab>("overview")

  const isAdmin = user?.role === "admin"

  // Stats queries
  const { data: contactStats } = trpc.contact.stats.useQuery(undefined, {
    enabled: isAdmin,
  })
  const { data: newsletterStats } = trpc.newsletter.stats.useQuery(undefined, {
    enabled: isAdmin,
  })

  // List queries
  const { data: contacts, isLoading: contactsLoading } =
    trpc.contact.list.useQuery(undefined, {
      enabled: isAdmin,
    })
  const { data: subscribers, isLoading: subscribersLoading } =
    trpc.newsletter.list.useQuery(undefined, {
      enabled: isAdmin,
    })

  // Mutations
  const utils = trpc.useUtils()

  const updateStatus = trpc.contact.updateStatus.useMutation({
    onSuccess: () => {
      utils.contact.list.invalidate()
      utils.contact.stats.invalidate()
      toast.success("Estado actualizado")
    },
  })

  const deleteContact = trpc.contact.delete.useMutation({
    onSuccess: () => {
      utils.contact.list.invalidate()
      utils.contact.stats.invalidate()
      toast.success("Mensaje eliminado")
    },
  })

  const deleteSubscriber = trpc.newsletter.delete.useMutation({
    onSuccess: () => {
      utils.newsletter.list.invalidate()
      utils.newsletter.stats.invalidate()
      toast.success("Suscriptor eliminado")
    },
  })

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate("/login")
    }
  }, [authLoading, isAuthenticated, navigate])

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#1A120B] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#D84315] animate-spin" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#1A120B] flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-['Playfair_Display'] text-3xl text-[#FFF8E1] mb-4">
            Acceso Restringido
          </h1>
          <p className="text-[#BCAAA4] mb-6">
            No tienes permisos para acceder al panel administrativo.
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#D84315] text-[#FFF8E1] font-semibold hover:bg-[#BF360C] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver al Inicio
          </Link>
        </div>
      </div>
    )
  }

  const sidebarItems: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Dashboard", icon: LayoutDashboard },
    { id: "messages", label: "Mensajes", icon: MessageSquare },
    { id: "subscribers", label: "Suscriptores", icon: Users },
  ]

  const totalMessages = contactStats?.total ?? 0
  const pendingMessages = contactStats?.pending ?? 0
  const totalSubscribers = newsletterStats?.total ?? 0

  return (
    <div className="min-h-screen bg-[#1A120B] flex">
      {/* Sidebar */}
      <aside className="w-[260px] bg-[#0D0906] border-r border-[#3E2723] flex flex-col fixed h-full">
        <div className="p-6 border-b border-[#3E2723]">
          <Link to="/" className="flex items-center gap-2">
            <LayoutDashboard className="w-6 h-6 text-[#D84315]" />
            <span className="font-['Playfair_Display'] text-lg font-bold text-[#FFF8E1]">
              Admin
            </span>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {sidebarItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  activeTab === item.id
                    ? "bg-[#D84315] text-[#FFF8E1]"
                    : "text-[#BCAAA4] hover:bg-[#2C1810] hover:text-[#FFF8E1]"
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </button>
            )
          })}
        </nav>

        <div className="p-4 border-t border-[#3E2723] space-y-1">
          <div className="flex items-center gap-3 px-4 py-3 text-sm text-[#BCAAA4]">
            <Settings className="w-5 h-5" />
            Configuracion
          </div>
          <button
            onClick={() => logout()}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm text-[#BCAAA4] hover:bg-[#2C1810] hover:text-[#FFF8E1] transition-all"
          >
            <LogOut className="w-5 h-5" />
            Cerrar Sesion
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-[260px] p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-['Playfair_Display'] text-2xl font-semibold text-[#FFF8E1]">
              {activeTab === "overview" && "Dashboard"}
              {activeTab === "messages" && "Mensajes"}
              {activeTab === "subscribers" && "Suscriptores"}
            </h1>
            <p className="text-sm text-[#BCAAA4] mt-1">
              Bienvenido, {user?.name || "Administrador"}
            </p>
          </div>
          <Link
            to="/"
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#3E2723] text-sm text-[#BCAAA4] hover:text-[#FFF8E1] hover:border-[#D84315] transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver al sitio
          </Link>
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(216,67,21,0.2)] flex items-center justify-center">
                    <Inbox className="w-5 h-5 text-[#D84315]" />
                  </div>
                  <span className="text-xs text-[#BCAAA4]">Total</span>
                </div>
                <div className="text-3xl font-bold text-[#FFF8E1]">{totalMessages}</div>
                <div className="text-sm text-[#BCAAA4] mt-1">Mensajes</div>
              </div>

              <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(1,87,155,0.2)] flex items-center justify-center">
                    <Mail className="w-5 h-5 text-[#01579B]" />
                  </div>
                  <span className="text-xs text-[#BCAAA4]">Nuevos</span>
                </div>
                <div className="text-3xl font-bold text-[#FFF8E1]">{pendingMessages}</div>
                <div className="text-sm text-[#BCAAA4] mt-1">Pendientes</div>
              </div>

              <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(255,183,77,0.2)] flex items-center justify-center">
                    <UserCheck className="w-5 h-5 text-[#FFB74D]" />
                  </div>
                  <span className="text-xs text-[#BCAAA4]">Total</span>
                </div>
                <div className="text-3xl font-bold text-[#FFF8E1]">{totalSubscribers}</div>
                <div className="text-sm text-[#BCAAA4] mt-1">Suscriptores</div>
              </div>

              <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(102,187,106,0.2)] flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-[#66BB6A]" />
                  </div>
                  <span className="text-xs text-[#BCAAA4]">Conversion</span>
                </div>
                <div className="text-3xl font-bold text-[#FFF8E1]">
                  {totalMessages > 0
                    ? `${Math.round((totalSubscribers / (totalMessages + totalSubscribers || 1)) * 100)}%`
                    : "0%"}
                </div>
                <div className="text-sm text-[#BCAAA4] mt-1">Tasa</div>
              </div>
            </div>

            {/* Recent Tables */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Messages */}
              <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl overflow-hidden">
                <div className="px-6 py-4 border-b border-[#3E2723] flex items-center justify-between">
                  <h3 className="font-semibold text-[#FFF8E1]">Ultimos Mensajes</h3>
                  <button
                    onClick={() => setActiveTab("messages")}
                    className="text-xs text-[#D84315] hover:underline"
                  >
                    Ver todos
                  </button>
                </div>
                <div className="divide-y divide-[#3E2723]">
                  {contactsLoading ? (
                    <div className="p-6 text-center text-[#BCAAA4]">
                      <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                    </div>
                  ) : contacts && contacts.length > 0 ? (
                    contacts.slice(0, 5).map((c) => (
                      <div key={c.id} className="px-6 py-4 flex items-center justify-between">
                        <div>
                          <div className="text-sm text-[#FFF8E1] font-medium">{c.name}</div>
                          <div className="text-xs text-[#BCAAA4]">{c.email}</div>
                        </div>
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            c.status === "pending"
                              ? "bg-[rgba(1,87,155,0.2)] text-[#01579B]"
                              : "bg-[rgba(102,187,106,0.2)] text-[#66BB6A]"
                          }`}
                        >
                          {c.status === "pending" ? "Pendiente" : "Leido"}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="p-6 text-center text-sm text-[#BCAAA4]">
                      No hay mensajes aun
                    </div>
                  )}
                </div>
              </div>

              {/* Recent Subscribers */}
              <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl overflow-hidden">
                <div className="px-6 py-4 border-b border-[#3E2723] flex items-center justify-between">
                  <h3 className="font-semibold text-[#FFF8E1]">Ultimos Suscriptores</h3>
                  <button
                    onClick={() => setActiveTab("subscribers")}
                    className="text-xs text-[#D84315] hover:underline"
                  >
                    Ver todos
                  </button>
                </div>
                <div className="divide-y divide-[#3E2723]">
                  {subscribersLoading ? (
                    <div className="p-6 text-center text-[#BCAAA4]">
                      <Loader2 className="w-5 h-5 animate-spin mx-auto" />
                    </div>
                  ) : subscribers && subscribers.length > 0 ? (
                    subscribers.slice(0, 5).map((s) => (
                      <div key={s.id} className="px-6 py-4 flex items-center justify-between">
                        <div className="text-sm text-[#FFF8E1]">{s.email}</div>
                        <div className="text-xs text-[#BCAAA4]">
                          {new Date(s.createdAt).toLocaleDateString("es-CL")}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-6 text-center text-sm text-[#BCAAA4]">
                      No hay suscriptores aun
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === "messages" && (
          <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-[#3E2723]">
              <h3 className="font-semibold text-[#FFF8E1]">Todos los Mensajes</h3>
            </div>
            {contactsLoading ? (
              <div className="p-12 text-center">
                <Loader2 className="w-8 h-8 text-[#D84315] animate-spin mx-auto" />
              </div>
            ) : contacts && contacts.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#3E2723]">
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Nombre
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Ubicacion
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Mensaje
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-[#BCAAA4] uppercase">
                        Acciones
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#3E2723]">
                    {contacts.map((c) => (
                      <tr key={c.id} className="hover:bg-[rgba(62,39,35,0.3)] transition-colors">
                        <td className="px-6 py-4 text-sm text-[#FFF8E1]">{c.name}</td>
                        <td className="px-6 py-4 text-sm text-[#BCAAA4]">{c.email}</td>
                        <td className="px-6 py-4 text-sm text-[#BCAAA4] capitalize">
                          {c.location.replace("_", " ")}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#BCAAA4] max-w-[200px] truncate">
                          {c.message}
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`text-xs px-2 py-1 rounded-full ${
                              c.status === "pending"
                                ? "bg-[rgba(1,87,155,0.2)] text-[#01579B]"
                                : "bg-[rgba(102,187,106,0.2)] text-[#66BB6A]"
                            }`}
                          >
                            {c.status === "pending" ? "Pendiente" : "Leido"}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {c.status === "pending" && (
                              <button
                                onClick={() =>
                                  updateStatus.mutate({ id: c.id, status: "read" })
                                }
                                className="p-1.5 rounded-lg text-[#BCAAA4] hover:text-[#66BB6A] hover:bg-[rgba(102,187,106,0.1)] transition-colors"
                                title="Marcar como leido"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                            )}
                            <button
                              onClick={() => deleteContact.mutate({ id: c.id })}
                              className="p-1.5 rounded-lg text-[#BCAAA4] hover:text-[#EF5350] hover:bg-[rgba(239,83,80,0.1)] transition-colors"
                              title="Eliminar"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-12 text-center text-[#BCAAA4]">
                No hay mensajes registrados
              </div>
            )}
          </div>
        )}

        {/* Subscribers Tab */}
        {activeTab === "subscribers" && (
          <div className="bg-[#2C1810] border border-[#3E2723] rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-[#3E2723] flex items-center justify-between">
              <h3 className="font-semibold text-[#FFF8E1]">Todos los Suscriptores</h3>
              {subscribers && subscribers.length > 0 && (
                <button
                  onClick={() => {
                    const csv = [
                      "Email,Fecha",
                      ...subscribers.map(
                        (s) =>
                          `${s.email},${new Date(s.createdAt).toLocaleDateString("es-CL")}`
                      ),
                    ].join("\n")
                    const blob = new Blob([csv], { type: "text/csv" })
                    const url = URL.createObjectURL(blob)
                    const a = document.createElement("a")
                    a.href = url
                    a.download = "lambert-coffee-suscriptores.csv"
                    a.click()
                    URL.revokeObjectURL(url)
                  }}
                  className="text-xs text-[#D84315] hover:underline"
                >
                  Exportar CSV
                </button>
              )}
            </div>
            {subscribersLoading ? (
              <div className="p-12 text-center">
                <Loader2 className="w-8 h-8 text-[#D84315] animate-spin mx-auto" />
              </div>
            ) : subscribers && subscribers.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#3E2723]">
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Fuente
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#BCAAA4] uppercase">
                        Fecha
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-[#BCAAA4] uppercase">
                        Acciones
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#3E2723]">
                    {subscribers.map((s) => (
                      <tr key={s.id} className="hover:bg-[rgba(62,39,35,0.3)] transition-colors">
                        <td className="px-6 py-4 text-sm text-[#FFF8E1]">{s.email}</td>
                        <td className="px-6 py-4 text-sm text-[#BCAAA4] capitalize">
                          {s.source}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#BCAAA4]">
                          {new Date(s.createdAt).toLocaleDateString("es-CL")}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => deleteSubscriber.mutate({ id: s.id })}
                            className="p-1.5 rounded-lg text-[#BCAAA4] hover:text-[#EF5350] hover:bg-[rgba(239,83,80,0.1)] transition-colors"
                            title="Eliminar"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-12 text-center text-[#BCAAA4]">
                No hay suscriptores registrados
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
