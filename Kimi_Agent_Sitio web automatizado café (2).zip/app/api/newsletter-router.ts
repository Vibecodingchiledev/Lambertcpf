import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { subscribers } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const newsletterRouter = createRouter({
  subscribe: publicQuery
    .input(
      z.object({
        email: z.string().email("Email inválido"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      try {
        await db.insert(subscribers).values({
          email: input.email,
          source: "website",
        });
        return { success: true, message: "Suscripción exitosa" };
      } catch {
        return {
          success: true,
          message: "Ya estás suscrito",
        };
      }
    }),

  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(subscribers).orderBy(desc(subscribers.createdAt));
  }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(subscribers).where(eq(subscribers.id, input.id));
      return { success: true };
    }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(subscribers);
    const monthly = await db
      .select({
        month: sql<string>`DATE_FORMAT(${subscribers.createdAt}, '%Y-%m')`,
        count: sql<number>`COUNT(*)`,
      })
      .from(subscribers)
      .groupBy(sql`DATE_FORMAT(${subscribers.createdAt}, '%Y-%m')`)
      .orderBy(sql`DATE_FORMAT(${subscribers.createdAt}, '%Y-%m')`);

    return {
      total: all.length,
      monthly,
    };
  }),
});
