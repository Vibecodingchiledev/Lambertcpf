import { authRouter } from "./auth-router";
import { contactRouter } from "./contact-router";
import { newsletterRouter } from "./newsletter-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  contact: contactRouter,
  newsletter: newsletterRouter,
});

export type AppRouter = typeof appRouter;
